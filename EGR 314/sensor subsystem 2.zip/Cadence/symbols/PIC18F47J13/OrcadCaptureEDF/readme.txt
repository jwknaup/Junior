 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\1\992\Output\OrcadCaptureEDF\OrcadCaptureEDF.edf
 
 
To import your new library part to OrCAD Capture CIS:
1. Start OrCAD Capture CIS.
2. Select File\Import Design from the menu.
3. Select the EDIF tab.
4. Browse to the correct EDIF file in the "Open" Window.  Note that it will not see
the "edif " directory by default.
5. Verify remaining settings.
6. Press Okay.

A library will be imported for you.  Use File\Open\Library from the menu to view your library.

If you recieve an XML file instead of Edif the operation is similar.
1. Start OrCAD Capture CIS.
2. Select File\Import from the menu.
3. Select the Library XML menu option.
4. Browse to the correct XML file in the "XML to OLB" Window.
5. Select the new Target OLB file.
6. Verify remaining settings.
7. Press Okay.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/OrcadCapture_import.html

To view a video tutorial, please visit:
http://youtube/1Kd4T5mFKnQ
 
 
Symbol "PIC18F47J13-I/ML" renamed to "PIC18F47J13-IML"
Symbol "PIC18F47J53-X/PT" renamed to "PIC18F47J53-XPT"
Component "PIC18F47J13-I/ML" renamed to "PIC18F47J13-IML"
Component "PIC18F47J53-X/PT" renamed to "PIC18F47J53-XPT"


Ultra Librarian Gold 8.2.139 Process Report


Message - Pattern "QFN44_8x8MC", entity (470-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (472-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (475-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (477-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (480-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (482-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (485-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (487-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (490-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (492-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (495-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (497-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (500-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (502-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (505-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (507-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (510-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (512-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (515-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (517-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (520-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (522-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (525-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (527-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (530-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (532-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (535-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (537-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (540-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (542-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (545-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (547-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (550-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (552-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (555-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (557-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (560-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (562-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (565-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (567-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (570-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (572-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (575-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (577-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (580-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (582-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (585-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (587-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (590-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (592-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (595-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (597-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (600-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (602-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (605-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (607-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (610-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (612-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (615-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (617-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (620-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (622-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (625-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (627-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (630-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (632-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (635-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (637-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (640-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (642-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (647-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (650-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (652-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (655-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (657-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (660-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (662-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (665-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (667-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (670-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (672-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (675-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (677-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (680-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (682-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (685-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (687-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (698-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (700-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (702-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8x8MC", entity (704-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (470-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (472-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (475-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (477-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (480-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (482-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (485-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (487-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (490-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (492-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (495-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (497-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (500-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (502-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (505-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (507-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (510-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (512-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (515-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (517-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (520-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (522-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (525-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (527-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (530-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (532-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (535-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (537-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (540-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (542-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (545-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (547-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (550-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (552-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (555-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (557-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (560-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (562-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (565-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (567-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (570-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (572-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (575-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (577-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (580-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (582-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (585-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (587-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (590-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (592-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (595-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (597-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (600-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (602-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (605-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (607-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (610-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (612-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (615-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (617-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (620-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (622-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (625-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (627-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (630-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (632-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (635-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (637-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (640-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (642-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (647-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (650-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (652-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (655-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (657-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (660-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (662-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (665-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (667-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (670-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (672-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (675-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (677-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (680-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (682-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (685-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (687-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (698-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (700-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (702-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-M", entity (704-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (470-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (472-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (475-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (477-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (480-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (482-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (485-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (487-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (490-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (492-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (495-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (497-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (500-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (502-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (505-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (507-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (510-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (512-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (515-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (517-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (520-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (522-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (525-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (527-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (530-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (532-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (535-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (537-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (540-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (542-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (545-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (547-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (550-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (552-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (555-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (557-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (560-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (562-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (565-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (567-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (570-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (572-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (575-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (577-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (580-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (582-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (585-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (587-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (590-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (592-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (595-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (597-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (600-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (602-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (605-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (607-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (610-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (612-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (615-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (617-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (620-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (622-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (625-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (627-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (630-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (632-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (635-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (637-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (640-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (642-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (647-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (650-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (652-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (655-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (657-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (660-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (662-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (665-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (667-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (670-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (672-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (675-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (677-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (680-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (682-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (685-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (687-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (698-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (700-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (702-LINE) is a LINE with matching start and end points.
Message - Pattern "QFN44_8X8MC-L", entity (704-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (645-LINE) is a LINE with matching start and end points.
Symbol "PIC18F47J13-I/ML" was renamed to "PIC18F47J13-IML".
Symbol "PIC18F47J53-X/PT" was renamed to "PIC18F47J53-XPT".
Symbol "PIC18F47J13-I/ML_1" was renamed to "PIC18F47J13-IML_1".
Symbol "PIC18F47J53-X/PT_1" was renamed to "PIC18F47J53-XPT_1".

TextStyle count:  25
Padstack count:   7
Pattern count:    6
Symbol count:     4
Component count:  2

Export

Text style "DEFAULT" renamed to "DEFAULT_0"
Component "PIC18F47J53-XPT" duplicate pin name "NC" changed to "NC_1"
Component "PIC18F47J53-XPT" duplicate pin name "NC" changed to "NC_2"
Component "PIC18F47J53-XPT" duplicate pin name "NC" changed to "NC_3"
