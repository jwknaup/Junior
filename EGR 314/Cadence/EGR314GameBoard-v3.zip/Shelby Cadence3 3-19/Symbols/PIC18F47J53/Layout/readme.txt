 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\1\991\Output\Layout\Layout.min
 
 
To import your new library part to Orcad Layout:
1. Start Orcad Layout.
2. Select File\Import\Min Interchange from the menu.
3. Browse to the file we have created.
A library will be imported for you.


For additional information, please visit this site:
http://www.accelerated-designs.com/help/OrcadLayout_import.html
 
 


Ultra Librarian Gold 8.2.139 Process Report


Message - Pattern "TQFP44_10x10MC", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10x10MC", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-M", entity (645-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (639-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (641-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (643-LINE) is a LINE with matching start and end points.
Message - Pattern "TQFP44_10X10MC-L", entity (645-LINE) is a LINE with matching start and end points.

TextStyle count:  26
Padstack count:   3
Pattern count:    3
Symbol count:     1
Component count:  1

Export

